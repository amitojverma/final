package com.cts.bookShopping.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.AddToCart;
import com.cts.bookShopping.bean.Books;

@Repository("addToCartDAO")

public class AddToCartDAOImpl implements AddToCartDAO {
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	@Transactional
	public String addCartDetails(AddToCart addToCart) {
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		session.save(addToCart);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		
		return "false";		
	}

	@Transactional
	public List<AddToCart> viewCartDetails(String id) {
		Session session = null;
		
	      try {
	    	  String query= "from addToCart where userId = ?";
	    		Query<AddToCart> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				query2.setParameter(0, id);
	    				List<AddToCart> books = query2.getResultList();
	    				if(books==null)
	    					return null;
	    				else
	    					return books;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
	      
		return null;
	}
	@Transactional
	public String deleteCartItem(int id) {
		Session session = null;
		String query= "from addToCart where cartId = ?";
		Query<AddToCart> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, id);
			AddToCart product = query2.getSingleResult();
			session.delete(product);
				return "true";
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

}

package com.cts.bookShopping.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bookShopping.bean.userRegistration;
import com.cts.bookShopping.service.RegisterationService;
@Controller
public class RegistrationController {
	@Autowired
	RegisterationService registrationService;
	
	
	@RequestMapping(value="userRegistration.html", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute userRegistration userregistration,HttpSession httpSession){
		//session
		
		
		System.out.println(userregistration);
		if("true".equals(registrationService.setUserDetails(userregistration)))
		{
			System.out.println(userregistration);
			
			//modelAndView.setViewName(".html");
			return "login";
		}
		else
		{
			return "no";
		}
		
	}
	

}

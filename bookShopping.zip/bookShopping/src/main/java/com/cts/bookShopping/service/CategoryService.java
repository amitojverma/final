package com.cts.bookShopping.service;

import java.util.List;

import com.cts.bookShopping.bean.Category;

public interface CategoryService {
	public List<Category> getCategoryName();
	public List<Category> getAllCategory();
	public String insertCategory(Category cat);
	public Category viewCategoryByName(String categoryName);
}
